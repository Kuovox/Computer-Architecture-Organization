----------------------------------------------------------------------------------
-- Company: 
-- Engineer: Khoa Vu
-- 
-- Create Date: 04/12/2024 02:08:17 PM
-- Design Name: 
-- Module Name: adder_subtractor_4bit_testbench - Behavioral
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------


library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity adder_subtractor_4bit_testbench is
end adder_subtractor_4bit_testbench;
architecture Behavioral of adder_subtractor_4bit_testbench is
    signal A, B: std_logic_vector(3 downto 0);
    signal K: std_logic_vector(0 downto 0);
    signal SUM: std_logic_vector(4 downto 0);
    component adder_subtractor_4bit_wrapper
        port (
            A : in std_logic_vector(3 downto 0);
            B : in std_logic_vector(3 downto 0);
            K : in std_logic_vector(0 downto 0);
            SUM : out std_logic_vector(4 downto 0)
        );
        end component adder_subtractor_4bit_wrapper;
begin
    adder_subtractor_4bit: adder_subtractor_4bit_wrapper
        port map (
            A => A,
            B => B,
            K => K,
            SUM => SUM
        );
process
begin
        A <= "1111"; B <= "1000"; K <= "0"; wait for 20ns;
        A <= "1110"; B <= "0110"; K <= "0"; wait for 20ns;
        A <= "1000"; B <= "0100"; K <= "0"; wait for 20ns;
        A <= "0110"; B <= "1100"; K <= "0"; wait for 20ns;
        A <= "1001"; B <= "0001"; K <= "1"; wait for 20ns;
        A <= "0001"; B <= "0010"; K <= "1"; wait for 20ns;
        A <= "1111"; B <= "1110"; K <= "1"; wait for 20ns;
        A <= "0110"; B <= "0010"; K <= "1"; wait for 20ns;
end process;
end Behavioral;
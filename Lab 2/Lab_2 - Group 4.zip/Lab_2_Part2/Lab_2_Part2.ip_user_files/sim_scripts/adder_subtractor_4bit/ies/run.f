-makelib ies_lib/xil_defaultlib \
  "../../../bd/adder_subtractor_4bit/ip/adder_subtractor_4bit_FA_0_0/sim/adder_subtractor_4bit_FA_0_0.vhd" \
  "../../../bd/adder_subtractor_4bit/ip/adder_subtractor_4bit_FA_0_1/sim/adder_subtractor_4bit_FA_0_1.vhd" \
  "../../../bd/adder_subtractor_4bit/ip/adder_subtractor_4bit_FA_0_2/sim/adder_subtractor_4bit_FA_0_2.vhd" \
  "../../../bd/adder_subtractor_4bit/ip/adder_subtractor_4bit_FA_0_3/sim/adder_subtractor_4bit_FA_0_3.vhd" \
-endlib
-makelib ies_lib/util_vector_logic_v2_0_1 \
  "../../../../Lab_2_Part2.srcs/sources_1/bd/adder_subtractor_4bit/ipshared/2137/hdl/util_vector_logic_v2_0_vl_rfs.v" \
-endlib
-makelib ies_lib/xil_defaultlib \
  "../../../bd/adder_subtractor_4bit/ip/adder_subtractor_4bit_util_vector_logic_0_0/sim/adder_subtractor_4bit_util_vector_logic_0_0.v" \
  "../../../bd/adder_subtractor_4bit/ip/adder_subtractor_4bit_util_vector_logic_0_2/sim/adder_subtractor_4bit_util_vector_logic_0_2.v" \
  "../../../bd/adder_subtractor_4bit/ip/adder_subtractor_4bit_util_vector_logic_1_0/sim/adder_subtractor_4bit_util_vector_logic_1_0.v" \
  "../../../bd/adder_subtractor_4bit/ip/adder_subtractor_4bit_util_vector_logic_1_1/sim/adder_subtractor_4bit_util_vector_logic_1_1.v" \
-endlib
-makelib ies_lib/xlslice_v1_0_2 \
  "../../../../Lab_2_Part2.srcs/sources_1/bd/adder_subtractor_4bit/ipshared/11d0/hdl/xlslice_v1_0_vl_rfs.v" \
-endlib
-makelib ies_lib/xil_defaultlib \
  "../../../bd/adder_subtractor_4bit/ip/adder_subtractor_4bit_xlslice_0_0/sim/adder_subtractor_4bit_xlslice_0_0.v" \
  "../../../bd/adder_subtractor_4bit/ip/adder_subtractor_4bit_xlslice_0_1/sim/adder_subtractor_4bit_xlslice_0_1.v" \
  "../../../bd/adder_subtractor_4bit/ip/adder_subtractor_4bit_xlslice_0_2/sim/adder_subtractor_4bit_xlslice_0_2.v" \
  "../../../bd/adder_subtractor_4bit/ip/adder_subtractor_4bit_xlslice_0_3/sim/adder_subtractor_4bit_xlslice_0_3.v" \
  "../../../bd/adder_subtractor_4bit/ip/adder_subtractor_4bit_xlslice_3_0/sim/adder_subtractor_4bit_xlslice_3_0.v" \
  "../../../bd/adder_subtractor_4bit/ip/adder_subtractor_4bit_xlslice_3_1/sim/adder_subtractor_4bit_xlslice_3_1.v" \
  "../../../bd/adder_subtractor_4bit/ip/adder_subtractor_4bit_xlslice_5_0/sim/adder_subtractor_4bit_xlslice_5_0.v" \
  "../../../bd/adder_subtractor_4bit/ip/adder_subtractor_4bit_xlslice_5_1/sim/adder_subtractor_4bit_xlslice_5_1.v" \
-endlib
-makelib ies_lib/xlconcat_v2_1_3 \
  "../../../../Lab_2_Part2.srcs/sources_1/bd/adder_subtractor_4bit/ipshared/442e/hdl/xlconcat_v2_1_vl_rfs.v" \
-endlib
-makelib ies_lib/xil_defaultlib \
  "../../../bd/adder_subtractor_4bit/ip/adder_subtractor_4bit_xlconcat_0_0/sim/adder_subtractor_4bit_xlconcat_0_0.v" \
-endlib
-makelib ies_lib/xil_defaultlib \
  "../../../bd/adder_subtractor_4bit/sim/adder_subtractor_4bit.vhd" \
-endlib
-makelib ies_lib/xil_defaultlib \
  glbl.v
-endlib


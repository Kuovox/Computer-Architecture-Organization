----------------------------------------------------------------------------------
-- Company: 
-- Engineer: Khoa Vu
-- 
-- Create Date: 03/25/2024 01:10:06 PM
-- Design Name: 
-- Module Name: logic_circuit - Behavioral
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------


library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity logic_circuit is
port( A,B,C: in STD_LOGIC; F: out STD_LOGIC );
end logic_circuit;

architecture bool_exp of logic_circuit is
begin
    F <= (A and B) or (not (A) and C ) or (A and not (B) and not (C));

end bool_exp;

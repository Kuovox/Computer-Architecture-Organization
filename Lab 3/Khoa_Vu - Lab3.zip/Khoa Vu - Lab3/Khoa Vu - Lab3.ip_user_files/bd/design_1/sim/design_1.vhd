--Copyright 1986-2019 Xilinx, Inc. All Rights Reserved.
----------------------------------------------------------------------------------
--Tool Version: Vivado v.2019.2 (win64) Build 2708876 Wed Nov  6 21:40:23 MST 2019
--Date        : Fri May  3 14:23:22 2024
--Host        : svl-ll-prod036 running 64-bit major release  (build 9200)
--Command     : generate_target design_1.bd
--Design      : design_1
--Purpose     : IP block netlist
----------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity design_1 is
  port (
    A : in STD_LOGIC_VECTOR ( 31 downto 0 );
    ALUCntl : in STD_LOGIC_VECTOR ( 3 downto 0 );
    ALUout : out STD_LOGIC_VECTOR ( 31 downto 0 );
    B : in STD_LOGIC_VECTOR ( 31 downto 0 );
    Carryin : in STD_LOGIC_VECTOR ( 0 to 0 );
    Cout : out STD_LOGIC_VECTOR ( 0 to 0 );
    Overflow : out STD_LOGIC_VECTOR ( 0 to 0 );
    Zero : out STD_LOGIC_VECTOR ( 0 to 0 )
  );
  attribute CORE_GENERATION_INFO : string;
  attribute CORE_GENERATION_INFO of design_1 : entity is "design_1,IP_Integrator,{x_ipVendor=xilinx.com,x_ipLibrary=BlockDiagram,x_ipName=design_1,x_ipVersion=1.00.a,x_ipLanguage=VHDL,numBlks=1,numReposBlks=1,numNonXlnxBlks=0,numHierBlks=0,maxHierDepth=0,numSysgenBlks=0,numHlsBlks=0,numHdlrefBlks=1,numPkgbdBlks=0,bdsource=USER,synth_mode=OOC_per_IP}";
  attribute HW_HANDOFF : string;
  attribute HW_HANDOFF of design_1 : entity is "design_1.hwdef";
end design_1;

architecture STRUCTURE of design_1 is
  component design_1_ALU_0_0 is
  port (
    A : in STD_LOGIC_VECTOR ( 31 downto 0 );
    B : in STD_LOGIC_VECTOR ( 31 downto 0 );
    ALUCntl : in STD_LOGIC_VECTOR ( 3 downto 0 );
    Carryin : in STD_LOGIC;
    ALUout : out STD_LOGIC_VECTOR ( 31 downto 0 );
    Zero : out STD_LOGIC;
    Cout : out STD_LOGIC;
    Overflow : out STD_LOGIC
  );
  end component design_1_ALU_0_0;
  signal ALUCntl_1 : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal ALU_0_ALUout : STD_LOGIC_VECTOR ( 31 downto 0 );
  signal ALU_0_Cout : STD_LOGIC;
  signal ALU_0_Overflow : STD_LOGIC;
  signal ALU_0_Zero : STD_LOGIC;
  signal A_1 : STD_LOGIC_VECTOR ( 31 downto 0 );
  signal B_1 : STD_LOGIC_VECTOR ( 31 downto 0 );
  signal Carryin_1 : STD_LOGIC_VECTOR ( 0 to 0 );
  attribute X_INTERFACE_INFO : string;
  attribute X_INTERFACE_INFO of A : signal is "xilinx.com:signal:data:1.0 DATA.A DATA";
  attribute X_INTERFACE_PARAMETER : string;
  attribute X_INTERFACE_PARAMETER of A : signal is "XIL_INTERFACENAME DATA.A, LAYERED_METADATA undef";
  attribute X_INTERFACE_INFO of ALUCntl : signal is "xilinx.com:signal:data:1.0 DATA.ALUCNTL DATA";
  attribute X_INTERFACE_PARAMETER of ALUCntl : signal is "XIL_INTERFACENAME DATA.ALUCNTL, LAYERED_METADATA undef";
  attribute X_INTERFACE_INFO of ALUout : signal is "xilinx.com:signal:data:1.0 DATA.ALUOUT DATA";
  attribute X_INTERFACE_PARAMETER of ALUout : signal is "XIL_INTERFACENAME DATA.ALUOUT, LAYERED_METADATA undef";
  attribute X_INTERFACE_INFO of B : signal is "xilinx.com:signal:data:1.0 DATA.B DATA";
  attribute X_INTERFACE_PARAMETER of B : signal is "XIL_INTERFACENAME DATA.B, LAYERED_METADATA undef";
  attribute X_INTERFACE_INFO of Carryin : signal is "xilinx.com:signal:data:1.0 DATA.CARRYIN DATA";
  attribute X_INTERFACE_PARAMETER of Carryin : signal is "XIL_INTERFACENAME DATA.CARRYIN, LAYERED_METADATA undef";
  attribute X_INTERFACE_INFO of Cout : signal is "xilinx.com:signal:data:1.0 DATA.COUT DATA";
  attribute X_INTERFACE_PARAMETER of Cout : signal is "XIL_INTERFACENAME DATA.COUT, LAYERED_METADATA undef";
  attribute X_INTERFACE_INFO of Overflow : signal is "xilinx.com:signal:data:1.0 DATA.OVERFLOW DATA";
  attribute X_INTERFACE_PARAMETER of Overflow : signal is "XIL_INTERFACENAME DATA.OVERFLOW, LAYERED_METADATA undef";
  attribute X_INTERFACE_INFO of Zero : signal is "xilinx.com:signal:data:1.0 DATA.ZERO DATA";
  attribute X_INTERFACE_PARAMETER of Zero : signal is "XIL_INTERFACENAME DATA.ZERO, LAYERED_METADATA undef";
begin
  ALUCntl_1(3 downto 0) <= ALUCntl(3 downto 0);
  ALUout(31 downto 0) <= ALU_0_ALUout(31 downto 0);
  A_1(31 downto 0) <= A(31 downto 0);
  B_1(31 downto 0) <= B(31 downto 0);
  Carryin_1(0) <= Carryin(0);
  Cout(0) <= ALU_0_Cout;
  Overflow(0) <= ALU_0_Overflow;
  Zero(0) <= ALU_0_Zero;
ALU_0: component design_1_ALU_0_0
     port map (
      A(31 downto 0) => A_1(31 downto 0),
      ALUCntl(3 downto 0) => ALUCntl_1(3 downto 0),
      ALUout(31 downto 0) => ALU_0_ALUout(31 downto 0),
      B(31 downto 0) => B_1(31 downto 0),
      Carryin => Carryin_1(0),
      Cout => ALU_0_Cout,
      Overflow => ALU_0_Overflow,
      Zero => ALU_0_Zero
    );
end STRUCTURE;

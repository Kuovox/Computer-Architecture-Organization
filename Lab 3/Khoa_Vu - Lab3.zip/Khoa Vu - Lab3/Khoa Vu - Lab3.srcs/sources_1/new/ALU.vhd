----------------------------------------------------------------------------------
-- Company: 
-- Engineer: Khoa Vu
-- 
-- Create Date: 04/29/2024 10:28:37 PM
-- Design Name: 
-- Module Name: ALU - Behavioral
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;
use ieee.NUMERIC_STD.ALL;

entity ALU is
    port (A, B      : in STD_LOGIC_VECTOR (31 downto 0);
          ALUCntl   : in STD_LOGIC_VECTOR (3 downto 0);
          ALUout    : out STD_LOGIC_VECTOR (31 downto 0);
          Carryin   : in STD_LOGIC;
          Zero      : out STD_LOGIC;
          Cout      : out STD_LOGIC;
          Overflow  : out STD_LOGIC
          );
          
end ALU;

architecture Behavioral of ALU is
    signal ALU_Result : STD_LOGIC_VECTOR (31 downto 0);
    signal a32, b32, c32 : std_logic_vector (32 downto 0):=(others=>'0');
    signal add_result, sub_result : std_logic_vector (32 downto 0);
    signal add_ov, sub_ov : std_logic;

begin
    a32 <= '0' & A;
    b32 <= '0' & B;
    c32(0) <= Carryin;
    
    add_result <= a32 + b32 + Carryin;
    sub_result <= a32 - b32;
    
    with ALUCntl select
        ALU_Result <= add_result (31 downto 0) when "0010",
                      sub_result (31 downto 0) when "0110",
                      A AND B when "0000",
                      A OR B when "0001",
                      A XOR B when "0011",
                      not (A OR B) when "1100",
                      (others => 'X') when others;
   
    Zero <= '1' when ALU_Result =x"00000000" else '0';
    
    -- Carryout flag
    Cout <= add_result(32) when ALUCntl = "0010" else
            sub_result(32) when ALUCntl = "0110" else
            'X';
    
    -- Overflow flag
    add_ov <= (A(31) and B(31) and (not ALU_Result(31))) or ((not A(31)) and (not B(31)) and ALU_Result(31));
    
    sub_ov <= (A(31) and (not B(31)) and (not ALU_Result(31))) or ((not A(31)) and B(31) and ALU_Result(31));
    
    with ALUCntl select
        Overflow <= add_ov when "0010",
                    sub_ov when "0110",
                    'Z' when others;
                    
    ALUout <= ALU_Result;
    
end Behavioral;

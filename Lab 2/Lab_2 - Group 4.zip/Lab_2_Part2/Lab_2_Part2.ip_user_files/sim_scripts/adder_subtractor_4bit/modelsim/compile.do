vlib modelsim_lib/work
vlib modelsim_lib/msim

vlib modelsim_lib/msim/xil_defaultlib
vlib modelsim_lib/msim/util_vector_logic_v2_0_1
vlib modelsim_lib/msim/xlslice_v1_0_2
vlib modelsim_lib/msim/xlconcat_v2_1_3

vmap xil_defaultlib modelsim_lib/msim/xil_defaultlib
vmap util_vector_logic_v2_0_1 modelsim_lib/msim/util_vector_logic_v2_0_1
vmap xlslice_v1_0_2 modelsim_lib/msim/xlslice_v1_0_2
vmap xlconcat_v2_1_3 modelsim_lib/msim/xlconcat_v2_1_3

vcom -work xil_defaultlib -64 -93 \
"../../../bd/adder_subtractor_4bit/ip/adder_subtractor_4bit_FA_0_0/sim/adder_subtractor_4bit_FA_0_0.vhd" \
"../../../bd/adder_subtractor_4bit/ip/adder_subtractor_4bit_FA_0_1/sim/adder_subtractor_4bit_FA_0_1.vhd" \
"../../../bd/adder_subtractor_4bit/ip/adder_subtractor_4bit_FA_0_2/sim/adder_subtractor_4bit_FA_0_2.vhd" \
"../../../bd/adder_subtractor_4bit/ip/adder_subtractor_4bit_FA_0_3/sim/adder_subtractor_4bit_FA_0_3.vhd" \

vlog -work util_vector_logic_v2_0_1 -64 -incr \
"../../../../Lab_2_Part2.srcs/sources_1/bd/adder_subtractor_4bit/ipshared/2137/hdl/util_vector_logic_v2_0_vl_rfs.v" \

vlog -work xil_defaultlib -64 -incr \
"../../../bd/adder_subtractor_4bit/ip/adder_subtractor_4bit_util_vector_logic_0_0/sim/adder_subtractor_4bit_util_vector_logic_0_0.v" \
"../../../bd/adder_subtractor_4bit/ip/adder_subtractor_4bit_util_vector_logic_0_2/sim/adder_subtractor_4bit_util_vector_logic_0_2.v" \
"../../../bd/adder_subtractor_4bit/ip/adder_subtractor_4bit_util_vector_logic_1_0/sim/adder_subtractor_4bit_util_vector_logic_1_0.v" \
"../../../bd/adder_subtractor_4bit/ip/adder_subtractor_4bit_util_vector_logic_1_1/sim/adder_subtractor_4bit_util_vector_logic_1_1.v" \

vlog -work xlslice_v1_0_2 -64 -incr \
"../../../../Lab_2_Part2.srcs/sources_1/bd/adder_subtractor_4bit/ipshared/11d0/hdl/xlslice_v1_0_vl_rfs.v" \

vlog -work xil_defaultlib -64 -incr \
"../../../bd/adder_subtractor_4bit/ip/adder_subtractor_4bit_xlslice_0_0/sim/adder_subtractor_4bit_xlslice_0_0.v" \
"../../../bd/adder_subtractor_4bit/ip/adder_subtractor_4bit_xlslice_0_1/sim/adder_subtractor_4bit_xlslice_0_1.v" \
"../../../bd/adder_subtractor_4bit/ip/adder_subtractor_4bit_xlslice_0_2/sim/adder_subtractor_4bit_xlslice_0_2.v" \
"../../../bd/adder_subtractor_4bit/ip/adder_subtractor_4bit_xlslice_0_3/sim/adder_subtractor_4bit_xlslice_0_3.v" \
"../../../bd/adder_subtractor_4bit/ip/adder_subtractor_4bit_xlslice_3_0/sim/adder_subtractor_4bit_xlslice_3_0.v" \
"../../../bd/adder_subtractor_4bit/ip/adder_subtractor_4bit_xlslice_3_1/sim/adder_subtractor_4bit_xlslice_3_1.v" \
"../../../bd/adder_subtractor_4bit/ip/adder_subtractor_4bit_xlslice_5_0/sim/adder_subtractor_4bit_xlslice_5_0.v" \
"../../../bd/adder_subtractor_4bit/ip/adder_subtractor_4bit_xlslice_5_1/sim/adder_subtractor_4bit_xlslice_5_1.v" \

vlog -work xlconcat_v2_1_3 -64 -incr \
"../../../../Lab_2_Part2.srcs/sources_1/bd/adder_subtractor_4bit/ipshared/442e/hdl/xlconcat_v2_1_vl_rfs.v" \

vlog -work xil_defaultlib -64 -incr \
"../../../bd/adder_subtractor_4bit/ip/adder_subtractor_4bit_xlconcat_0_0/sim/adder_subtractor_4bit_xlconcat_0_0.v" \

vcom -work xil_defaultlib -64 -93 \
"../../../bd/adder_subtractor_4bit/sim/adder_subtractor_4bit.vhd" \

vlog -work xil_defaultlib \
"glbl.v"

